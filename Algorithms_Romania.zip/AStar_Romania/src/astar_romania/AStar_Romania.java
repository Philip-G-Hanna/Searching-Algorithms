package astar_romania;

/**
 *
 * @author Philip George
 */
import java.util.*;

public class AStar_Romania {

    public static void AStar(Node source, Node goal) {

        List<Node> visited = new ArrayList<>();
        source.pathCost = 0;
        //Capacity and Comparator which imposes a total ordering on some collection of objects.
        //public int compare(Node i, Node j) or can use the lamda expression     
        PriorityQueue<Node> queue = new PriorityQueue<Node>(20, new Comparator<Node>() 
        {

            public int compare(Node i, Node j) 
            {
                if ((i.tillNow > j.tillNow)) 
                {
                    return 1;
                }

                else if (i.tillNow < j.tillNow) 
                {
                    return -1;
                }

                else 
                {
                    return 0;
                }
            }
        });

        queue.add(source);
        List<Node> path = new ArrayList<>();

        do {
            //remove all elements in the set
            path.clear();
            Node current = queue.poll();
            // Current Country Reached
            System.out.print(current + " -> ");
            // Explore current node
            visited.add(current);
            for (Node node = current; node != null; node = node.parent) {
                    path.add(node);
            }
            // If goal is found
            if (current.value.equals(goal.value)) 
            {
                goal.parent = current.parent;
                goal.pathCost = current.pathCost;
                System.out.println();
                System.out.println("A* search reached by current queue with cost : " + current);
                break;

            }
            for (neighbours e : current.edges) 
            {
                // we put each neighbour in a node that we call neighbour
                Node neighbour = e.target;
                // we put the cost of this neighbour in the variable we call cost
                int cost = e.cCost;

                /*
                  1. It is necessary that: 1.Waitlist contains this neighbour.
                    2. neighbour is already exploring.
                    3. neighbour must not be in path
                 */
                if ((queue.contains(neighbour) || visited.contains(neighbour)) && !path.contains(neighbour)) {
                    /*
                     If the conditions are checked then the neighbour 
                        is either in the waiting list or he is already 
                        exploring so we cannot add him directly to the waiting list, 
                        we must change his address so that he does not overwrite
                     */
                    Node n = new Node(neighbour);
                    n.pathCost = current.pathCost + cost;
                    n.tillNow = n.pathCost+n.heuristic;
                    n.parent = current;
                    // finally we add this neighbour to the waiting list
                    queue.add(n);
                } 
                else if (!path.contains(neighbour)) 
                {

                           //In the case where neighbour does not 
                           //belong to path only. Just update your cost 
                           //and add it to the waiting list
                    neighbour.pathCost = current.pathCost + cost ;
                    neighbour.tillNow = neighbour.pathCost+ neighbour.heuristic;
                    neighbour.parent = current;
                    queue.add(neighbour);
                }

            }
        } while (!queue.isEmpty());
        // As long as the waiting list is not empty

}

public static void main(String[] args) {
    // Heuristic costs of cities
    Node Arad = new Node("Arad",366);
    Node Zerind = new Node("Zerind",374);
    Node Oradea = new Node("Oradea",380);
    Node Sibiu = new Node("Sibiu",253);
    Node Fagaras = new Node("Fagaras",176);
    Node Rimnicu_Vilcea = new Node("Rimnicu Vilcea",193);
    Node Pitesti = new Node("Pitesti",100);
    Node Timisoara = new Node("Timisoara",329);
    Node Lugoj = new Node("Lugoj",244);
    Node Mehadia = new Node("Mehadia",241);
    Node Drobeta = new Node("Drobeta",242);
    Node Craiova = new Node("Craiova",160);
    Node Bucharest = new Node("Bucharest",0);
    Node Giurgui = new Node("Giurgiu",77);

    // edges of cities
    Arad.edges = new neighbours[] { new neighbours(Zerind, 75), new neighbours(Sibiu, 140), new neighbours(Timisoara, 118) };

    Zerind.edges = new neighbours[] { new neighbours(Arad, 75), new neighbours(Oradea, 71) };

    Oradea.edges = new neighbours[] { new neighbours(Zerind, 71), new neighbours(Sibiu, 151) };

    Sibiu.edges = new neighbours[] { new neighbours(Arad, 140), new neighbours(Fagaras, 99), new neighbours(Oradea, 151), new neighbours(Rimnicu_Vilcea, 80), };

    Fagaras.edges = new neighbours[] { new neighbours(Sibiu, 99), new neighbours(Bucharest, 211) };

    Rimnicu_Vilcea.edges = new neighbours[] { new neighbours(Sibiu, 80), new neighbours(Pitesti, 97), new neighbours(Craiova, 146) };

    Pitesti.edges = new neighbours[] { new neighbours(Rimnicu_Vilcea, 97), new neighbours(Bucharest, 101), new neighbours(Craiova, 138) };

    Timisoara.edges = new neighbours[] { new neighbours(Arad, 118), new neighbours(Lugoj, 111) };

    Lugoj.edges = new neighbours[] { new neighbours(Timisoara, 111), new neighbours(Mehadia, 70) };

    Mehadia.edges = new neighbours[] { new neighbours(Lugoj, 70), new neighbours(Drobeta, 75) };

    Drobeta.edges = new neighbours[] { new neighbours(Mehadia, 75), new neighbours(Craiova, 120) };

    Craiova.edges = new neighbours[] { new neighbours(Drobeta, 120), new neighbours(Rimnicu_Vilcea, 146), new neighbours(Pitesti, 138) };

    Bucharest.edges = new neighbours[] { new neighbours(Pitesti, 101), new neighbours(Giurgui, 90), new neighbours(Fagaras, 211) };

    Giurgui.edges = new neighbours[] { new neighbours(Bucharest, 90) };

    AStar(Arad, Bucharest);

    }

}
class Node{
    public final String value;
    public int pathCost;
    public int heuristic;
    public neighbours[] edges;
    public Node parent;
    public int tillNow;
    public Node(String val,int h) {

            value = val;
            heuristic =h;
    }

    public Node(Node node) {
            int i = 0;
            edges = new neighbours[node.edges.length];
            value = node.value;
            pathCost = node.pathCost;
            heuristic = node.heuristic;
            for (neighbours e : node.edges) {
                    edges[i++] = e;
            }
            parent = node.parent;
    }

    public String toString() {
            return value + "(" +pathCost + ")";
    }
}

class neighbours {
	public int cCost;
	public Node target;
	public neighbours(Node targetNode, int costVal) {
		cCost = costVal;
		target = targetNode;
	}

}
