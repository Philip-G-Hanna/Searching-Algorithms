/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ucs_romania;

/**
 *
 * @author Philip George
 */
import java.util.*;

public class UCS_Romania 
{
    
    public static void main(String[] args) 
    {
        Node n1 = new Node("Arad");
        Node n2 = new Node("Zerind");
        Node n3 = new Node("Oradea");
        Node n4 = new Node("Sibiu");
        Node n5 = new Node("Fagaras");
        Node n6 = new Node("Rimnicu Vilcea");
        Node n7 = new Node("Pitesti");
        Node n8 = new Node("Timisoara");
        Node n9 = new Node("Lugoj");
        Node n10 = new Node("Mehadia");
        Node n11 = new Node("Drobeta");
        Node n12 = new Node("Craiova");
        Node n13 = new Node("Bucharest");
        Node n14 = new Node("Giurgiu");

        // initialize the edges
        n1.neighbours = new Edge[] { new Edge(n2, 75), new Edge(n4, 140), new Edge(n8, 118) };

        n2.neighbours = new Edge[] { new Edge(n1, 75), new Edge(n3, 71) };

        n3.neighbours = new Edge[] { new Edge(n2, 71), new Edge(n4, 151) };

        n4.neighbours = new Edge[] { new Edge(n1, 140), new Edge(n5, 99), new Edge(n3, 151), new Edge(n6, 80), };

        n5.neighbours = new Edge[] { new Edge(n4, 99), new Edge(n13, 211) };

        n6.neighbours = new Edge[] { new Edge(n4, 80), new Edge(n7, 97), new Edge(n12, 146) };

        n7.neighbours = new Edge[] { new Edge(n6, 97), new Edge(n13, 101), new Edge(n12, 138) };

        n8.neighbours = new Edge[] { new Edge(n1, 118), new Edge(n9, 111) };

        n9.neighbours = new Edge[] { new Edge(n8, 111), new Edge(n10, 70) };

        n10.neighbours = new Edge[] { new Edge(n9, 70), new Edge(n11, 75) };

        n11.neighbours = new Edge[] { new Edge(n10, 75), new Edge(n12, 120) };

        n12.neighbours = new Edge[] { new Edge(n11, 120), new Edge(n6, 146), new Edge(n7, 138) };

        n13.neighbours = new Edge[] { new Edge(n7, 101), new Edge(n14, 90), new Edge(n5, 211) };

        n14.neighbours = new Edge[] { new Edge(n13, 90) };

        UniformCostSearch(n1, n13);

        List<Node> path = printPath(n13);

        System.out.println("Path: " + path);

    }

    public static void UniformCostSearch(Node source, Node goal)
    {
        List<Node> list = new ArrayList<>();
        source.pathCost = 0;
        PriorityQueue<Node> queue = new PriorityQueue<Node>(20, new Comparator<Node>() 
        {

            // override compare method
            public int compare(Node i, Node j)
            {
                if ((i.pathCost > j.pathCost))
                {
                    return 1;
                }

                else if (i.pathCost < j.pathCost) 
                {
                    return -1;
                }

                else 
                {
                    return 0;
                }
            }
        });

        queue.add(source);
        Set<Node> visited = new HashSet<>();
        List<Node> path = new ArrayList<>();

        // while frontier is not empty
        do {

            path.clear();
            Node current = queue.poll();
            visited.add(current);
            for (Node node = current; node != null; node = node.parent)
            {
                path.add(node);
            }
            if (current.value.equals(goal.value)) 
            {
                goal.parent = current.parent;
                goal.pathCost = current.pathCost;
                break;
            }

            for (Edge e : current.neighbours)
            {
                Node child = e.target;
                int cost = e.cost;
                if ((queue.contains(child) || visited.contains(child)) && !path.contains(child))
                {
                    Node n = new Node(child);
                    list.add(n);
                    list.get(list.size() - 1).pathCost = current.pathCost + cost;
                    list.get(list.size() - 1).parent = current;
                    queue.add(list.get(list.size() - 1));

                    System.out.println(list.get(list.size() - 1));
                    System.out.println(queue);
                } 
                else if (!path.contains(child))
                {
                    child.pathCost = current.pathCost + cost;
                    child.parent = current;
                    queue.add(child);

                    System.out.println(child);
                    System.out.println(queue);
                }

            }
        } while (!queue.isEmpty());

    }
    

    public static List<Node> printPath(Node target) 
    {
        List<Node> path = new ArrayList<>();
        for (Node node = target; node != null; node = node.parent)
        {
            path.add(node);
        }

        Collections.reverse(path);

        return path;

    }
}

class Node
{
    public final String value;
    public int pathCost;
    public Edge[] neighbours;
    public Node parent;

    public Node(String val) 
    {
        value = val;
    }

    public Node(Node node)
    {
        int count = 0;
        neighbours = new Edge[node.neighbours.length];
        value = node.value;
        pathCost = node.pathCost;
        for (Edge e : node.neighbours) 
        {
            neighbours[count++] = e;
        }
        parent = node.parent;
    }

    @Override
    public String toString()
    {
        return value + pathCost + "   ";
    }

}
class Edge 
{
    public final int cost;
    public final Node target;

    public Edge(Node targetNode, int costVal) 
    {
        cost = costVal;
        target = targetNode;
    }
}
