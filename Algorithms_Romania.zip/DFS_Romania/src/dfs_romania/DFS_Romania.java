package dfs_romania;

import java.io.*;
import java.util.*;
/**
 *
 * @author Mafdy
 */

public class DFS_Romania
{
     public static void main(String args[]) throws IOException

     {   

          String cities[]={"Arad", "Bucharest", "Craiova", "Drobeta",
              
                          "Eforie", "Fagaras", "Giurgiu", "Hirsova",
                          
                          "Iasi", "Lugoj", "Mehadia", "Neamt", "Oradea",
                          
                          "Pitesti", "RimnicuVilcea", "Sibiu",

                         "Timisoara", "Urziceni", "Vaslui", "Zerind"
                         };

          Arrays.sort(cities);         

          // create adjacency matrix and set each value in the

          // matrix with -1

          int adj[][]=new int[50][50];

          for(int i=0;i<adj.length;i++)

              for(int j=0;j<adj.length;j++)

                   adj[i][j]=-1;

          // open the input file

          File file = new File("C:\\Users\\Philip Braveheart\\Documents\\NetBeansProjects\\DFS_Romania\\roadmap.txt");

          BufferedReader br = new BufferedReader(new FileReader(file));

          Scanner input=new Scanner(System.in);

          // read line by line

          String st;

          while ((st = br.readLine()) != null)

          {

              // split the line

              String str[]=st.split(" ");

              int i=0,j=0;

              // find the index of the first city in the cities array

              for(;i<cities.length;i++)

              {

                   if(cities[i].equals(str[0].trim()))

                        break;

              }

              // find the index of the second city in the cities array

              for(;j<cities.length;j++)

              {

                   if(cities[j].equals(str[1].trim()))

                        break;

              }   

              // store the distance between two cities into adjacency matrix

              adj[i][j]=adj[j][i]=Integer.parseInt(str[2]);             

          }   

          // prompt for source city and destination city

          System.out.println("Please the source city");

          String start=input.next().trim();
          System.out.println("Please the destination city");
          String end=input.next().trim();
          //DFS
          dfs(start,end,adj,cities);

     }

     public static void dfs(String start,String end,int adj[][],String cities[])

     {   

          boolean found=false;

          // find the indices of the source and destination cities in the cities array

          int i=0,j=0;

          for(;i<cities.length;i++)

          {

              if(cities[i].equals(start))

                   break;

          }

          for(;j<cities.length;j++)

          {

              if(cities[j].equals(end))

                   break;

          }        

          Stack<Integer> s=new Stack<>();

          int visited[]=new int[adj.length];

          int previous[]=new int[adj.length];

          // set source city as the start city

          int v=i;

          // set v as visited

          visited[v]=1;

          // set previous city of v as -1

          previous[v]=-1;

          // push the start city into stack

          s.push(v);

         

          int next;

          // repeat until the stack is not empty

          while(!s.empty())

          {

              // pop a city

              next=s.pop();

              // if the city is not visited yet,

              // set it as visited

              if( visited[next]!=1)

              {            

              visited[next]=1;

              }

              // if next is the destination city

              // exit the loop

              if(next==j)

              {

                   // set flag found as true

                   found=true;

                   break;

              }

              // push the unvisited neighbors of next

              for(int k=adj.length-1;k>=0;k--)

              {

                   if(adj[next][k]!=-1 && visited[k]!=1)

                   {

                        previous[k]=next;

                        s.push(k);

                   }

              }            

          }

          // if path found, print path between source and

          // destination cities with distance between them

          if(found==true)

          {

              int m=j,n;

              int sum=0;

              String path=cities[m];

              while(previous[m]!=-1)

              {

                   path=cities[previous[m]]+" -> "+path;

                   n=m;

                   m=previous[m];              

                   sum=sum+adj[m][n];

              }

              System.out.println("Path: " + path);
              System.out.println("Cost of DFS from " + start + " to " + end + " = " + sum);

          }

          else

              System.out.println("No path found between "+start +"and "+end);

     }
}