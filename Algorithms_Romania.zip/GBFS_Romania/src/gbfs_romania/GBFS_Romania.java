package gbfs_romania;

import java.util.*;

/**
 *
 * @author Philip
 */

public class GBFS_Romania {


    private Map<String, AdjList> romaniaMap;

    public static void main(String[] args) {
        GBFS("Arad", "Bucharest");

    }
    public static void GBFS(String start, String end) {
        GBFS_Romania roads = new GBFS_Romania();
        //Launch program using init function
        roads.init();
        AdjList path = roads.romaniaMap.get(start);
        AdjNode startNode = findNode(path, start);
        System.out.print(start + "(" + startNode.cost + ")" + "-->");
        int totalCost = 0;
        while (path.size() > 0) {
            AdjNode nextNode = path.poll(); //returns the path at the front of queue(AdjList).
            int nodeCost = nextNode.cost;
            totalCost += nodeCost;

            System.out.print(nextNode.name + "(" + nodeCost + ")-->");
            path = roads.romaniaMap.get(nextNode.name);

            if (isExist(path, end)) {
                int lastNodeCost = path.poll().cost;
                totalCost += lastNodeCost;
                System.out.println(end + "(" + lastNodeCost + ").");
                System.out.println("Total cost of the greedy best first search is : " + totalCost);
                return;
            }
        }
    }

    /**
     * init Touring in Romania road map
     */
    public void init() 
    {
        romaniaMap = new HashMap<>();

        String name = "Arad";
        int cost = 366;
        AdjList adjList = new AdjList();
        //Heuristic Costs
        adjList.add(new AdjNode("Arad", 366));
        adjList.add(new AdjNode("Zerind", 374));
        adjList.add(new AdjNode("Sibiu", 253));
        adjList.add(new AdjNode("Timisoara", 329));
        romaniaMap.put(name, adjList);

        name = "Sibiu";
        adjList = new AdjList();
        adjList.add(new AdjNode("Fagaras", 176));
        adjList.add(new AdjNode("Rimnicu", 193));
        adjList.add(new AdjNode("Rimnicu", 380));
        romaniaMap.put(name, adjList);

        name = "Fagaras";
        adjList = new AdjList();
        adjList.add(new AdjNode("Sibiu", 253));
        adjList.add(new AdjNode("Bucharest", 0));
        romaniaMap.put(name, adjList);
    }

    /**
     *
     * @param adjList
     * @param name
     * @return
     */
    public static boolean isExist(AdjList adjList, String name) 
    {
        for (AdjNode n : adjList) 
        {
            if (n.name.equals(name)) 
            {
                return true;
            }
        }
        return false;
    }

    public static AdjNode findNode(AdjList adjList, String name) 
    {
        for (AdjNode n : adjList) 
        {
            if (n.name.equals(name)) 
            {
                return n;
            }
        }
        return null;
    }
}

class AdjList extends PriorityQueue<AdjNode> {
    //class to use object of priority queue
}

class AdjNode implements Comparable<AdjNode> {
    String name;
    int cost;

    public AdjNode(String name, int cost) {
        this.name = name;
        this.cost = cost;
    }

    @Override
    public int compareTo(AdjNode o) {
        return Integer.compare(cost, o.cost);
    }

    @Override
    public String toString() {
        return "AdjNode{" + "name='" + name + '\'' + ", cost=" + cost + '}';
    }
}