package bfs_romania;

import java.io.*;
import java.util.*;
/**
 *
 * @author Mafdy
 */

public class BFS_Romania

{

     public static void main(String args[]) throws IOException

     {   

          String romanian_cities[]={"Arad", "Bucharest", "Craiova", "Drobeta",
              
                          "Eforie", "Fagaras", "Giurgiu", "Hirsova",
                          
                          "Iasi", "Lugoj", "Mehadia", "Neamt", "Oradea",
                          
                          "Pitesti", "RimnicuVilcea", "Sibiu",

                         "Timisoara", "Urziceni", "Vaslui", "Zerind"
                         };

          Arrays.sort(romanian_cities);         

          // create adjacency matrix in order to store the cities in

          int adj[][]=new int[50][50];

          for(int i=0;i<adj.length;i++)

              for(int j=0;j<adj.length;j++)

                   adj[i][j]=-1;

          // open the input file

          File file = new File("C:\\Users\\Philip Braveheart\\Documents\\NetBeansProjects\\BFS_Romania\\roadmap.txt");

          BufferedReader br = new BufferedReader(new FileReader(file));

          Scanner input=new Scanner(System.in);

          // read line by line

          String st;

          while ((st = br.readLine()) != null)

          {

              // split the line

              String str[]=st.split(" ");

              int i,j;

              // find the index of the first city in the cities array

              for(i=0;i<romanian_cities.length;i++)

              {

                   if(romanian_cities[i].equals(str[0].trim()))

                        break;

              }

              // find the index of the second city in the cities array

              for(j=0;j<romanian_cities.length;j++)

              {

                   if(romanian_cities[j].equals(str[1].trim()))

                        break;

              }   

              // store the distance between two cities into adjacency matrix

              adj[i][j]=adj[j][i]=Integer.parseInt(str[2]);             

          }   
          
          System.out.println("Please the source city");

          String start=input.next().trim();
          System.out.println("Please the destination city");
          String end=input.next().trim();
         
              bfs(start,end,adj,romanian_cities);
     }
        public static void bfs(String start, String end,int adj[][],String cities[])

     {

          // find the indices of the source and destination cities in the cities array

          int i,j;

          for(i=0;i<cities.length;i++)

          {

              if(cities[i].equals(start))

                   break;

          }

          for(j=0;j<cities.length;j++)

          {

              if(cities[j].equals(end))

                   break;

          }   

          boolean found=false;

          int previous[]=new int[adj.length];

          Queue<Integer> q=new LinkedList<>();

          int visited[]=new int[adj.length];

          // set source city as the start city

          int v=i;

          // set v as visited

         visited[v] = 1;

         // set previous city of v as -1

         previous[v]=-1;

         // insert the start city into queue

         q.add(v);

        

         int next;

         // repeat until the stack is not empty

         while (!q.isEmpty())

         {

         // remove a city

             next = q.peek();

             q.remove();

             // if next is the destination city

               // exit the loop

             if(next==j)

             {

             found=true;

             break;

             }                  

             // insert the unvisited neighbors of next

             for (int k = 0;k<adj.length; k++)

             {

                 if (adj[next][k] != -1 && visited[k]!=1)

                 {

                    // set next as the previous city in

                    // the path to city k

                    previous[k]=next;

                     // insert the neighbor to the queue

                     q.add(k);               

                    // set the city as visited

                     visited[k] = 1;

                 }

             }

         }

         // if path found, print path between source and

          // destination cities with distance between them

         if(found==true)

          {

              int m=j;
              int n;

              int sum=0;

              String path=cities[m];

              while(previous[m]!=-1)

              {

                   path=cities[previous[m]] + " -> " + path;

                   n=m;

                   m=previous[m];              

                   sum+=adj[m][n];

              }

              System.out.println("Path: " + path);
              System.out.println("Cost of BFS from " + start + " to " + end + " = " + sum);

          }

         // otherwise, print the message "There is no path between given two cities"

          else

              System.out.println("There is no path between " + start +" and " + end);

     }
}